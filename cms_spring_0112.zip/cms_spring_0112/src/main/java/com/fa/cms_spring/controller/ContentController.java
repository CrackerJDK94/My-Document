/*-============================================================================
 * PizSoft. PROPRIETARY
 * Copyright© 2021 PizSoft.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 *
 * This software is the confidential and proprietary information of
 * PizSoft. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * PizSoft. providing access to this software.
 *
 *=============================================================================
 */
package com.fa.cms_spring.controller;

import com.fa.cms_spring.model.entity.Content;
import com.fa.cms_spring.model.entity.Member;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * @author <a href="mailto:phuongdp.tech@gmail.com">PhuongDP</a>
 */
@Controller
public class ContentController extends BaseController {

    @GetMapping("/content")
    public String showViewContent(@RequestParam(name = "q", defaultValue = "abc") Optional<String> search,
                                  @RequestParam(required = false) Integer page,
                                  @RequestParam(name = "id", required = false) List<String> ids,
                                  Model model) {
        Member member = currentMemberLogin();
        List<Content> contents = Arrays.asList(
                Content.builder().id(1L).title("Tittle").build(),
                Content.builder().id(2L).title("Tittle 2").build()
        );
        model.addAttribute("contents", contents);
        return "view-content";
    }

    // file/{file_url}
    @GetMapping({"/content/{id}/{type}", "/content/{id}"})
    public String showDetail(@PathVariable(name = "id") Long contentId,
                             @PathVariable(required = false) Optional<String> type) {

        return "view-content";
    }
}
