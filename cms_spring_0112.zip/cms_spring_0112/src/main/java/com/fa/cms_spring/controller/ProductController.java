/*-============================================================================
 * PizSoft. PROPRIETARY
 * Copyright© 2021 PizSoft.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 *
 * This software is the confidential and proprietary information of
 * PizSoft. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * PizSoft. providing access to this software.
 *
 *=============================================================================
 */
package com.fa.cms_spring.controller;

import com.fa.cms_spring.model.dto.ProductDto;
import com.fa.cms_spring.model.dto.resp.ProductDetailResponse;
import com.fa.cms_spring.model.entity.Product;
import com.fa.cms_spring.model.enums.StatusEnum;
import com.fa.cms_spring.service.FileStorageService;
import com.fa.cms_spring.service.ProductService;
import com.fa.cms_spring.util.FileUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

/**
 * @author <a href="mailto:phuongdp.tech@gmail.com">PhuongDP</a>
 */
@Controller
@RequestMapping("/product")
public class ProductController extends BaseController {

    @Autowired
    FileStorageService fileStorageService;

    @Autowired
    ProductService productService;

    @GetMapping()
    public String showProduct(Model model) {
        model.addAttribute("productDto", new ProductDto());
        return "form-product";
    }

    @GetMapping("/{id}")
    public String detailProduct(@PathVariable Long id, Model model) {
        Product product = productService.getById(id);

        ProductDetailResponse resp = ProductDetailResponse.builder()
                .name(product.getName())
                .url(fileStorageService.buildUrl(product.getUrl()))
                .build();

        model.addAttribute("product", resp);
        return "product-detail";
    }

    @PostMapping()
    public String submitProduct(@ModelAttribute ProductDto productDto) throws IOException {
        Product product = new Product();
        BeanUtils.copyProperties(productDto, product);

        String url = fileStorageService.saveFile(productDto.getFile(),
                "user_" + currentMemberLogin().getId());
        product.setUrl(url);
        product.setStatusEnum(StatusEnum.ACTIVE);

        productService.save(product);

        return "form-product";
    }
}
