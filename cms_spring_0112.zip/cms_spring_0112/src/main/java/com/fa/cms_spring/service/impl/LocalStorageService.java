/*-============================================================================
 * PizSoft. PROPRIETARY
 * Copyright© 2021 PizSoft.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 *
 * This software is the confidential and proprietary information of
 * PizSoft. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * PizSoft. providing access to this software.
 *
 *=============================================================================
 */
package com.fa.cms_spring.service.impl;

import com.fa.cms_spring.service.FileStorageService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

/**
 * @author <a href="mailto:phuongdp.tech@gmail.com">PhuongDP</a>
 */
@Service
public class LocalStorageService implements FileStorageService {

    @Value("${app.file.location}")
    String fileLocation;

    @Value("${app.file.url-prefix}")
    String urlPrefix;

    @Override
    public String saveFile(MultipartFile file, String folderUser) throws IOException {
        Path filePath = getFilePath(file.getOriginalFilename(), folderUser);

        // Save file to success
        file.transferTo(filePath);

        return filePath.toString().replace(fileLocation, "");
    }

    @Override
    public Resource loadFileAsResource(String filePath) throws MalformedURLException, FileNotFoundException {
        // fileLocation: /Users/phuongdp/Projects/FA/Class/FJB_02/Courseware/9. JWD/Demo/cms_spring/assets
        // filePath: user3/favicon.png
         Path absolutePath = Paths.get(fileLocation).resolve(filePath);
         Resource resource = new UrlResource(absolutePath.toUri());
         if (resource.exists()) {
             return resource;
         }

         throw new FileNotFoundException("File not found: " + absolutePath.toString());
    }

    private Path getFilePath(String fileName, String folderUser) throws IOException {
        // product1.png
        // user_1 + "/" +  random
        // .../assets
        // => /Users/phuongdp/Projects/FA/Class/FJB_02/Courseware/9. JWD/Demo/cms_spring/assets/user_1/abcd123/product1.png
        Path fileLocationPath = Paths.get(fileLocation);

        if (Objects.nonNull(folderUser)) {
            fileLocationPath = fileLocationPath.resolve(folderUser);
        }
        Files.createDirectories(fileLocationPath);

        return fileLocationPath.resolve(fileName);
    }

    public String buildUrl(String relativePath) {
        return urlPrefix + relativePath;
    }
}
