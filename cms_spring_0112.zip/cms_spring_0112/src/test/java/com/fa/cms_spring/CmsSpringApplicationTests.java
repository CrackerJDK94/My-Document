package com.fa.cms_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
